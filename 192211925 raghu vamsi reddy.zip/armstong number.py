num = int(input("enter the digits"))
sum = 0
temp = num          
while temp > 0:
    digit = temp % 10
    sum = sum + digit**3
    temp = temp//10
    if sum == num:
        print("Given number is armstrong number")
    else:
        print("Given number is not a armstrong number")
